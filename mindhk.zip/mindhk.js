var winHeight = $(window).height();
var height = ( winHeight * 16.6666 ) / 100;
var lineHeight = height + "px";

$("li").css("line-height", lineHeight);
$("li").css("height", height);
